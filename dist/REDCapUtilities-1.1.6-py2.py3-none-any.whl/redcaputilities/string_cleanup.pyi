from datetime import datetime as datetime
from typing import Union

import pandas  # type: ignore[import]

def clean_up_address(
    input_string: Union[str, list, pandas.Series]
) -> Union[str, list]: ...
def clean_up_date(
    input_string: Union[str, list, pandas.Series, datetime]
) -> Union[str, list]: ...
def clean_up_email(
    input_string: Union[str, list, pandas.Series]
) -> Union[str, list]: ...
def clean_up_phone(
    input_string: Union[str, list, pandas.Series]
) -> Union[str, list]: ...
def clean_up_string(
    input_string: Union[str, list, pandas.Series], strings_to_ignore: list
) -> Union[str, list]: ...
def clean_up_time(
    input_string: Union[str, list, pandas.Series]
) -> Union[str, list]: ...
def extend_street_abbreviations(street_address: str) -> str: ...
